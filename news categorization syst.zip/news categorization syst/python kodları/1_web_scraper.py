import requests #http isteği ve yanıtları için
from bs4 import BeautifulSoup

url = 'https://www.turkiyegazetesi.com.tr/spor' #bbc ekonomi
response = requests.get(url) #url çek
soup = BeautifulSoup(response.content, 'html.parser') #sayfa yapısını analiz ediyor.


print(soup.prettify()[:1000]) #ilk 1000

