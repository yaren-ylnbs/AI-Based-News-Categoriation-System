import requests
from bs4 import BeautifulSoup

def get_news_links(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')

    links = soup.find_all('a', href=True)  # a etiketinde link içeren etiketleri bul

    news_links = set()  # haber linklerini atacağız.
    for link in links:
        href = link['href']
        if '/economie/' in href:  # teknoloji haberleri için filtreleme
            full_url = requests.compat.urljoin(url, href)
            news_links.add(full_url)
    return list(news_links)

# Toplanan linkleri dosyaya yazma-ekleme
def write_links_to_file(links, filename):
    with open(filename, 'a', encoding='utf-8') as file:
        for link in links:
            file.write(f"{link}\n")

# URL'yi belirleyip fonksiyonları çalıştırma
base_url = 'https://actu.fr/economie'
all_news_links = []

for page in range(1, 11):  # 10 sayfada dönecek
    url = f"{base_url}/page/{page}"  # sayfa değiştiğinde ?page=2 oluyor, f-string ile bunu birleştirdik
    news_links = get_news_links(url)
    all_news_links.extend(news_links)  # Bulunan linkleri topluca ekle
    print(f"Sayfa {page} işleniyor, {len(news_links)} link bulundu ")

# Tüm linkleri bir dosyaya yazma
write_links_to_file(all_news_links, 'fr.ekonomi.txt')
print(f"Toplam {len(all_news_links)} link yazıldı.")
