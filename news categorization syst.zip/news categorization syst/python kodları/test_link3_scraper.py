import pytest 
from link2_scraper import get_news_links, write_links_to_file

def test_get_news_links():
    url =  'https://www.milliyet.com.tr/teknoloji/'
    links = get_news_links(url)

    assert isinstance(links,list), "çıktı liste olmalı"
    assert all(link.startswith('http') for link in links), "tüm linkler full url olmalı?"
    assert len(links)>0, "En az bir link bulunmalı"

def test_write_links_to_file():
    links = ["https://example.com/news1", "https://example.com/news2"]
    filename = "test_saglik.txt"
    write_links_to_file(links,filename)
    with open(filename,'r',encoding = 'utf-8') as file:
        written_links = file.readlines()
    assert len(written_links) == len(links), "metin sayısı link sayısıyla eşleşmelidir?"
    assert all(link.strip() == expected_link for link,expected_link in zip(written_links,links)) , "linkler eşleşmeli?"

if __name__ == "__main__":
    pytest.main()